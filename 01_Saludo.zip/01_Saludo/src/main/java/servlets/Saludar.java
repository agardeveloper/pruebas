package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*Un servlet es una clase que para que funcione como servlet hereda HttpServlet.
El m�todo service recibe dos objetos de tipo HttpServletResponse para respuesta
 y  HttpServletRequest para petici�n. 
 * @WebServlet
 * El servlet tiene una anotaci�n @WebServlet para decirle al servidor de 
 * aplicaciones que eso es un servlet
 * Y esto es la direcci�n ("/Saludar")
 */

@WebServlet("/Saludar")
public class Saludar extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	//M�todo del ciclo de vida
	//De los que hay, el m�s importante es el service
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.println("<html><body>"); 
		out.println("<h1>Bienvenido al servlet</h1>");
		out.println("</body></html>");
		out.close();
	}//fin m�todo servide

}//fin clase Saludar
